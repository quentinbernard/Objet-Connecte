import serial
import sys

#utiliser ce fichier avec python3

print (serial.__file__)

ser=serial.Serial('/dev/ttyAMA0',baudrate=115200,timeout=10)
ser.write([65,66])
sys.exit()
