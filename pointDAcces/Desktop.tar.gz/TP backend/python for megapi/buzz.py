from megapi import *
import time
import sys

bot = MegaPi()
bot.start()
bot.pwmWrite(5,50)
bot.exiting = True
sys.exit()
