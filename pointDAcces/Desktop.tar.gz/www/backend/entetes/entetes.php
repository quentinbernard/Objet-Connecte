<?php
header("Location:afficherEntetes.php");
?>
