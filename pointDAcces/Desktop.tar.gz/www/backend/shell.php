<?php

/*
string shell_exec ( string $cmd )
string exec ( string $command [, array &$output [, int &$return_var ]] )
void passthru ( string $command [, int &$return_var ] )
string system ( string $command [, int &$return_var ] )
*/

echo "<pre>";

echo shell_exec ("ls -l" );

echo "<hr />\n";

echo exec ("ls -l", $tab );
print_r($tab);

echo "</pre>";
?>


