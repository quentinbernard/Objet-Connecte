<?php
// fichier jouer.php
$notes = array("DO", "RE","MI", "FA", "SOL", "LA", "SI");
// les indices des cases de ce tableau sont numerotés à partir de 0

// La page reçoit une chaîne de requête, par la méthode GET
// qui contient une cle nommée note, pouvant valoir un entier de 1 à 7

// Il faut prévoir le cas où cette chaine ne comporte pas la clé recherchée, ou que la clé soit présente mais sans valeur.
// On utilise isset() ou la fonction valider() proposée sur moodle. 

if (isset($_GET["note"]) && ($_GET["note"] != 0) ) {
	$indice = $_GET["note"]-1;
	if (isset($notes[$indice])) 
		echo $notes[$indice];
}

?>

<!--Pour une meilleure expérience utilisateur, on affiche le formulaire dans la page elle-même-->

<form action="jouer.php" method="GET">
<input type="submit" name="note" value="1" /> 
<input type="submit" name="note" value="2" /> 
<input type="submit" name="note" value="3" /> 
<input type="submit" name="note" value="4" /> 
<input type="submit" name="note" value="5" /> 
<input type="submit" name="note" value="6" /> 
<input type="submit" name="note" value="7" /> 
</form>

